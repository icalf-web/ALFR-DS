@echo off
setlocal EnableExtensions
set PYTHONDONTWRITEBYTECODE=1
cd /d "%~dp0"
title Local AI Dashboard - Setup
set "ROOT=%CD%"
set "DATA=%LocalAppData%\LocalAIDash"
set "MODEL=qwen2.5:3b"

if not exist "%ROOT%\app\main.py" goto wrongplace

echo ============================================================
echo   Local AI Dashboard - one-click setup
echo ============================================================
echo This installs everything the app needs, one time (about 2.5 GB, needs internet):
echo   - Python, the AI engine and the AI model
echo   - the program itself, with your eye logo
echo   - a "Local AI Dashboard" icon on your Desktop
echo Nothing is uploaded. When setup finishes the app works fully offline.
echo Running Setup again repairs or refreshes everything.
echo.
choice /c YN /n /m "Press Y to start setup, or N to cancel: "
if errorlevel 2 goto cancel

call :killapp

echo.
echo [1/6] Python...
set "PY="
python --version >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PY=%LocalAppData%\Programs\Python\Python311\python.exe"
if defined PY goto havepy
echo       Installing Python for this user - please wait...
winget install -e --id Python.Python.3.11 --scope user --silent --accept-package-agreements --accept-source-agreements
if not exist "%DATA%" mkdir "%DATA%"
echo 1>"%DATA%\python_installed.flag"
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" set "PY=%LocalAppData%\Programs\Python\Python311\python.exe"
if defined PY goto havepy
echo.
echo Could not install Python automatically.
echo Install Python 3.11 from python.org, tick "Add python.exe to PATH", then run Setup.bat again.
pause
exit /b 1
:havepy
echo       OK

echo [2/6] Libraries...
if not exist ".venv\Scripts\python.exe" "%PY%" -m venv .venv
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check pandas openpyxl xlrd requests pywebview pyinstaller
if errorlevel 1 goto libfail
echo       OK

echo [3/6] AI engine...
if exist "ollama\ollama.exe" goto haveollama
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest https://github.com/ollama/ollama/releases/latest/download/ollama-windows-amd64.zip -OutFile ollama.zip; Expand-Archive -Force ollama.zip ollama; Remove-Item ollama.zip; Get-ChildItem ollama\lib\ollama -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(cuda|rocm)' } | Remove-Item -Recurse -Force"
if not exist "ollama\ollama.exe" goto engfail
:haveollama
echo       OK

echo [4/6] AI model - about 2 GB, one time...
if not exist "%DATA%" mkdir "%DATA%"
set "OLLAMA_MODELS=%DATA%\models"
start "" /min "%ROOT%\ollama\ollama.exe" serve
set /a TRIES=0
:waitup
curl -s http://127.0.0.1:11434 >nul 2>&1
if not errorlevel 1 goto serverup
set /a TRIES+=1
if %TRIES% GEQ 40 goto modelfail
timeout /t 1 /nobreak >nul
goto waitup
:serverup
"%ROOT%\ollama\ollama.exe" pull %MODEL%
if errorlevel 1 goto modelfail
echo       OK
goto modeldone
:modelfail
echo       Could not download the AI model now. The app will offer to download it on first start.
:modeldone
call :killapp

echo [5/6] Building the program with your logo - a few minutes...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --noconsole --name LocalAIDash --icon app\icon.ico --add-data "app\ui;ui" --add-data "app\icon.ico;." app\main.py >"%DATA%\build.log" 2>&1
if errorlevel 1 goto buildfail
xcopy /E /I /Y /Q ollama dist\LocalAIDash\ollama >nul
if exist build rmdir /s /q build
if exist LocalAIDash.spec del /q LocalAIDash.spec
set "TARGET=%ROOT%\dist\LocalAIDash\LocalAIDash.exe"
set "ARGS="
echo       OK
goto shortcut
:buildfail
echo       The program build was skipped (details: %DATA%\build.log).
echo       Using the standard launcher instead - everything still works.
set "TARGET=%ROOT%\.venv\Scripts\pythonw.exe"
set "ARGS=app\main.py"

:shortcut
echo [6/6] Desktop icon...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Local AI Dashboard.lnk'); $s.TargetPath='%TARGET%'; $s.Arguments='%ARGS%'; $s.WorkingDirectory='%ROOT%'; $s.IconLocation='%ROOT%\app\icon.ico'; $s.Description='Local AI Dashboard'; $s.Save()"
ie4uinit.exe -show
echo       OK
echo.
echo ============================================================
echo   Setup complete. Opening Local AI Dashboard...
echo   From now on use the "Local AI Dashboard" icon on your Desktop.
echo ============================================================
start "" "%TARGET%" %ARGS%
timeout /t 6 >nul
exit /b 0

:libfail
echo.
echo Library install failed. Check your internet connection, then run Setup.bat again.
pause
exit /b 1

:engfail
echo.
echo AI engine download failed. Check your internet connection, then run Setup.bat again.
pause
exit /b 1

:wrongplace
echo Please run Setup.bat from inside the LocalAIDash folder (the one that contains the "app" folder).
pause
exit /b 1

:cancel
echo Cancelled. Nothing was changed.
timeout /t 3 >nul
exit /b 0

:killapp
powershell -NoProfile -Command "Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and ($_.Path.StartsWith('%ROOT%\',[StringComparison]::OrdinalIgnoreCase) -or $_.Path.StartsWith('%DATA%\',[StringComparison]::OrdinalIgnoreCase)) } | Stop-Process -Force -ErrorAction SilentlyContinue"
timeout /t 1 /nobreak >nul
exit /b 0
