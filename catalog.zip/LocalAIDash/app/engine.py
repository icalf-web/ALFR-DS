"""Core engine: Excel -> profile -> (AI or rules) dashboard spec -> computed chart data.
Python does all the maths. The model only chooses what to show and writes the summary."""
import json
import pandas as pd
import requests

OLLAMA = "http://127.0.0.1:11434"
MODEL = "qwen2.5:3b"
AGGS = {"sum", "mean", "count", "max", "min"}
MAX_ITEMS = 1000  # safety cap only; every item up to this is shown
CHARTS = {"bar", "line", "doughnut"}


def _tonum(col):
    t = col.astype(str).str.replace(r"[,$€£₹%\s]", "", regex=True).replace({"": None, "nan": None, "None": None, "-": None})
    return pd.to_numeric(t, errors="coerce")


def load(path, sheet=None):
    if path.lower().endswith((".csv", ".txt")):
        raw = pd.read_csv(path, header=None)
    else:
        raw = pd.read_excel(path, sheet_name=sheet or 0, header=None)
    raw = raw.dropna(how="all").dropna(axis=1, how="all").reset_index(drop=True)
    hdr = 0  # find the real header row (skip title rows)
    for i in range(min(10, len(raw))):
        vals = raw.iloc[i].dropna()
        if len(vals) >= 0.6 * raw.shape[1] and sum(isinstance(v, str) for v in vals) >= 0.7 * len(vals):
            hdr = i
            break
    names, seen = [], {}
    for j, c in enumerate(raw.iloc[hdr]):
        n = str(c).strip() if pd.notna(c) else f"Column {j + 1}"
        seen[n] = seen.get(n, 0) + 1
        names.append(n if seen[n] == 1 else f"{n} ({seen[n]})")
    df = raw.iloc[hdr + 1:].copy()
    df.columns = names
    df = df.dropna(how="all").reset_index(drop=True)
    for c in df.columns:
        col = df[c]
        nn = col.dropna()
        if len(nn) == 0 or (pd.api.types.is_numeric_dtype(col) and col.dtype != object):
            continue
        samp = nn.head(200)
        if _tonum(samp).notna().mean() >= 0.8:
            num = _tonum(col)
            if num.notna().sum() >= 0.8 * len(nn):
                df[c] = num
                continue
        if pd.to_datetime(samp, errors="coerce", format="mixed").notna().mean() >= 0.8:
            dt = pd.to_datetime(col, errors="coerce", format="mixed")
            if dt.notna().sum() >= 0.8 * len(nn):
                df[c] = dt
                continue
        t = col.astype("object")
        m = t.notna()
        t[m] = t[m].astype(str).str.strip()
        df[c] = t
    return df


def profile(df):
    cols, n = [], len(df)
    for c in df.columns:
        s = df[c]
        u = int(s.nunique())
        if pd.api.types.is_datetime64_any_dtype(s):
            kind = "date"
        elif pd.api.types.is_numeric_dtype(s):
            ids = u == n and n > 3 and bool(__import__("re").search(r"\bid\b|no\.?$|number|code|#|sku", c, __import__("re").I))
            kind = "id" if ids else ("category" if u <= 2 else "number")
        elif u <= 20 and u < max(n * 0.9, 3):
            kind = "category"
        else:
            kind = "text"
        cols.append({"name": c, "kind": kind, "unique": u, "nulls": int(s.isna().sum())})
    return cols


def _valid(df, prof, spec):
    kinds = {p["name"]: p["kind"] for p in prof}
    kpis, charts = [], []
    for k in spec.get("kpis", [])[:4]:
        col, agg = k.get("column"), k.get("agg", "sum")
        if col in kinds and (agg == "count" or (kinds[col] == "number" and agg in AGGS)):
            kpis.append({"column": col, "agg": agg})
    for c in spec.get("charts", [])[:6]:
        x, y, agg, t = c.get("x"), c.get("y"), c.get("agg", "sum"), c.get("type", "bar")
        if x not in kinds or kinds[x] not in ("category", "date", "text") or agg not in AGGS or t not in CHARTS:
            continue
        if agg != "count" and not (y in kinds and kinds[y] == "number"):
            continue
        f, flt = c.get("filter"), None
        if isinstance(f, dict) and f.get("column") in kinds and f.get("value") not in (None, ""):
            flt = {"column": f["column"], "value": str(f["value"])}
        charts.append({"type": "line" if kinds[x] == "date" else t, "x": x,
                       "y": y if agg != "count" else None, "agg": agg, "filter": flt})
    return {"kpis": kpis, "charts": charts}


def rules_spec(df, prof):
    import re
    nums = [p["name"] for p in prof if p["kind"] == "number"]
    avg = lambda n: df[n].max() <= 10 or re.search(r"score|rate|days|time|%|margin|price|cost per|unit", n, re.I)
    key = lambda n: 0 if re.search(r"short|gap|risk|spend|revenue|sales|amount|value|loss|delay|backlog|cost", n, re.I) else 1
    sums = sorted([n for n in nums if not avg(n)], key=key)
    means = sorted([n for n in nums if avg(n)], key=key)
    cats = [p for p in prof if p["kind"] == "category" and p["unique"] > 1]
    cats.sort(key=lambda p: (p["unique"] > 12, p["unique"]))
    dates = [p["name"] for p in prof if p["kind"] == "date"]
    spec = {"kpis": [{"column": n, "agg": "sum"} for n in sums[:3]] +
                    [{"column": n, "agg": "mean"} for n in means[:2]] +
                    [{"column": df.columns[0], "agg": "count"}], "charts": []}
    pool = [(n, "sum") for n in sums] + [(n, "mean") for n in means]
    if dates:
        if pool:
            spec["charts"].append({"type": "line", "x": dates[0], "y": pool[0][0], "agg": pool[0][1]})
        else:
            spec["charts"].append({"type": "line", "x": dates[0], "y": None, "agg": "count"})
    for i, c in enumerate(cats[:4]):
        t = "doughnut" if c["unique"] <= 5 and i % 2 else "bar"
        if pool:
            y, a = pool[i % len(pool)]
            spec["charts"].append({"type": t, "x": c["name"], "y": y, "agg": a})
        else:
            spec["charts"].append({"type": t, "x": c["name"], "y": None, "agg": "count"})
    if pool and len(spec["charts"]) < 4:  # also show how many records per category
        for c in cats[:2]:
            spec["charts"].append({"type": "bar", "x": c["name"], "y": None, "agg": "count"})
    return spec


def _chat(prompt, as_json=False, timeout=90):
    body = {"model": MODEL, "stream": False, "messages": [{"role": "user", "content": prompt}],
            "keep_alive": "30m", "options": {"temperature": 0.2, "num_ctx": 2048}}
    if as_json:
        body["format"] = "json"
    r = requests.post(f"{OLLAMA}/api/chat", json=body, timeout=timeout)
    r.raise_for_status()
    return r.json()["message"]["content"]


def ai_spec(df, prof):
    sample = df.head(4).astype(str).to_dict("records")
    prompt = (
        "You design business dashboards. Given these columns and sample rows, return ONLY JSON:\n"
        '{"kpis":[{"column":"<number column>","agg":"sum|mean|max|min|count"}],'
        '"charts":[{"type":"bar|line|doughnut","x":"<category or date column>","y":"<number column>","agg":"sum|mean|count"}]}\n'
        "Use 3-4 kpis and 3-5 charts. Use only exact column names.\n"
        f"Columns: {json.dumps([(p['name'], p['kind']) for p in prof])}\nSample: {json.dumps(sample)}"
    )
    return json.loads(_chat(prompt, as_json=True))


def _agg(s, agg):
    return float(s.count() if agg == "count" else getattr(s, agg)())


def fmt(v):
    for lim, suf in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(v) >= lim:
            return f"{v / lim:.2f}{suf}"
    return f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}"


def compute(df, spec):
    kpis = []
    for k in spec["kpis"]:
        v = _agg(df[k["column"]], k["agg"])
        label = "Rows" if k["agg"] == "count" else f"{k['agg'].title()} of {k['column']}"
        kpis.append({"label": label, "value": fmt(v), "raw": v})
    charts = []
    for c in spec["charts"]:
        cnt = c["agg"] == "count"
        base, flt = df, c.get("filter")
        if flt:
            base = df[df[flt["column"]].astype(str).str.contains(flt["value"], case=False, regex=False)]
            if base.empty:
                continue
        d = base[[c["x"]] if cnt else [c["x"], c["y"]]].dropna()
        isdate = pd.api.types.is_datetime64_any_dtype(d[c["x"]])
        key = d[c["x"]].dt.to_period("M") if isdate else d[c["x"]]
        grp = d.groupby(key)
        g = grp.size() if cnt else grp[c["y"]].agg(c["agg"])
        total_n = len(g)
        g = g.sort_index() if isdate else g.sort_values(ascending=False).head(MAX_ITEMS)
        labels = [str(i) for i in g.index]
        verb = {"sum": "Total", "mean": "Average", "count": "Count of", "max": "Max", "min": "Min"}[c["agg"]]
        title = f"Number of records by {c['x']}" if cnt else f"{verb} {c['y']} by {c['x']}"
        if flt:
            title += f" ({flt['column']}: {flt['value']})"
        charts.append({"type": c["type"], "title": title, "n": total_n,
                       "spec": {k: c.get(k) for k in ("type", "x", "y", "agg", "filter")},
                       "labels": labels, "values": [round(float(v), 2) for v in g.values]})
    return kpis, charts


def summarize(kpis, charts, use_ai):
    facts = "; ".join(f"{k['label']}: {k['value']}" for k in kpis)
    for c in charts[:3]:
        if c["values"]:
            i = max(range(len(c["values"])), key=c["values"].__getitem__)
            facts += f"; in '{c['title']}' the top item is {c['labels'][i]} ({fmt(c['values'][i])})"
    if use_ai:
        try:
            return _chat("Write a 3-sentence plain-English business summary using ONLY these facts. "
                         "Do not invent numbers.\n" + facts).strip()
        except Exception:
            pass
    return facts + "."


_cache = {}


def get_df(path):
    import os
    key = (path, os.path.getmtime(path))
    if key not in _cache:
        _cache.clear()
        _cache[key] = load(path)
    return _cache[key]


def _cell(v):
    if v is None or (not isinstance(v, str) and pd.isna(v)):
        return ""
    if hasattr(v, "strftime"):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float):
        return f"{v:,.2f}".rstrip("0").rstrip(".")
    return str(v)[:40]


def info(path):
    df = get_df(path)
    prof = profile(df)
    return {"rows": len(df), "cols": len(df.columns),
            "columns": [{"name": p["name"], "kind": p["kind"]} for p in prof]}


def preview(path, n=200):
    df = get_df(path)
    rows = [[_cell(v) for v in r] for r in df.head(n).itertuples(index=False)]
    return {"cols": list(df.columns), "rows": rows, "total": len(df)}


def build(path, ai_ready=False):
    df = get_df(path)
    prof = profile(df)
    spec, used_ai = None, False
    if ai_ready:
        try:
            spec = _valid(df, prof, ai_spec(df, prof))
            used_ai = bool(spec["charts"])
        except Exception:
            spec = None
    if not spec or not spec["charts"]:
        spec = _valid(df, prof, rules_spec(df, prof))
    kpis, charts = compute(df, spec)
    _mark(charts)
    return {"rows": len(df), "cols": len(df.columns), "kpis": kpis, "charts": charts,
            "summary": summarize(kpis, charts, used_ai), "ai": used_ai,
            "columns": [{"name": p["name"], "kind": p["kind"]} for p in prof]}


# ---------------- Ask the AI (prompt box) ----------------
def _facts(kpis, charts):
    out = [f"{k['label']}: {k['value']}" for k in kpis]
    for c in charts:
        top = sorted(zip(c["labels"], c["values"]), key=lambda t: -t[1])[:5]
        out.append(c["title"] + " -> " + ", ".join(f"{a} = {fmt(b)}" for a, b in top))
    return "\n".join(out)


def ai_prompt_spec(df, prof, prompt):
    sample = df.head(3).astype(str).to_dict("records")
    q = (
        "You are a data analyst. Turn the user's request into 1-3 charts. Return ONLY JSON:\n"
        '{"charts":[{"type":"bar|line|doughnut","x":"<category or date column>","y":"<number column or null>",'
        '"agg":"sum|mean|count|max|min","filter":{"column":"<column>","value":"<text>"} or null}]}\n'
        "Use exact column names. Use agg count with y null to count records. Use filter only if the user names a specific value.\n"
        f"Request: {prompt}\nColumns: {json.dumps([(p['name'], p['kind']) for p in prof])}\nSample: {json.dumps(sample)}"
    )
    return json.loads(_chat(q, as_json=True))


def prompt_rules(df, prof, prompt):
    """Keyword fallback: measure = columns named before 'by', grouping = columns named after it."""
    import re
    p = prompt.lower()
    tok = lambda t: set(re.findall(r"[a-z0-9]+", t))
    words = tok(p)
    mby = re.search(r"\b(?:by|per|across|for each|grouped by)\b", p)
    head = tok(p[:mby.start()]) if mby else words
    tail = tok(p[mby.end():]) if mby else words

    def score(name, ws):
        toks = [t for t in re.findall(r"[a-z0-9]+", name.lower()) if len(t) > 2]
        m = sum(t in ws or t.rstrip("s") in ws for t in toks)
        return m, m / max(len(toks), 1)

    def best(kinds, ws, skip=()):
        c = [(score(q["name"], ws), -i, q["name"]) for i, q in enumerate(prof)
             if q["kind"] in kinds and q["name"] not in skip]
        c = [t for t in c if t[0][0] >= 1]
        return max(c)[2] if c else None

    if not any(score(q["name"], words)[0] >= 1 for q in prof):
        return {"kpis": [], "charts": []}
    flt = None
    for c in prof:
        if c["kind"] == "category" and c["unique"] <= 30:
            for v in df[c["name"]].dropna().astype(str).unique():
                if len(v) >= 2 and re.search(r"\b" + re.escape(v.lower()) + r"\b", p):
                    flt = {"column": c["name"], "value": v}
                    break
        if flt:
            break
    skip = (flt["column"],) if flt else ()
    has = lambda pat: re.search(r"\b(?:" + pat + r")\b", p)
    agg = "mean" if has("average|avg|mean") else "count" if has("count|how many|number of") \
        else "max" if has("max|maximum") else "min" if has("min|minimum") else "sum"
    t = "doughnut" if has("pie|donut|doughnut|share|split") else "line" if has("line|trend|over time|monthly|timeline") else "bar"
    gk = ("category", "text", "date")
    x = best(gk, tail, skip) or best(gk, words, skip)
    if x is None:
        rest = sorted([c for c in prof if c["kind"] == "category" and c["name"] not in skip], key=lambda c: c["unique"])
        x = rest[0]["name"] if rest else None
    if not x:
        return {"kpis": [], "charts": []}
    y = best(("number",), head) or best(("number",), words)
    sure = bool(mby and best(gk, tail, skip) and (y or has("count|how many|number of")))
    if not y:
        agg = "count"
    return {"kpis": [], "sure": sure,
            "charts": [{"type": t, "x": x, "y": None if agg == "count" else y, "agg": agg, "filter": flt}]}


def _answer(charts):
    out = []
    for c in charts:
        pairs = sorted(zip(c["labels"], c["values"]), key=lambda t: -t[1])
        if not pairs:
            continue
        hi, txt = pairs[0], f"{c['title']}: highest is {pairs[0][0]} at {fmt(pairs[0][1])}"
        if c["spec"]["agg"] in ("sum", "count") and len(pairs) > 1 and sum(v for _, v in pairs) > 0:
            txt += f" ({hi[1] / sum(v for _, v in pairs):.0%} of the total shown)"
        if len(pairs) > 2:
            txt += f"; lowest is {pairs[-1][0]} at {fmt(pairs[-1][1])}"
        out.append(txt + ".")
    return " ".join(out)


def ask(path, prompt, ai_ready=False):
    df = get_df(path)
    prof = profile(df)
    rs = prompt_rules(df, prof, prompt)
    spec, used = _valid(df, prof, rs), False
    if not (rs.get("sure") and spec["charts"]) and ai_ready:
        try:
            a = _valid(df, prof, ai_prompt_spec(df, prof, prompt))
            if a["charts"]:
                spec, used = a, True
        except Exception:
            pass
    kpis, charts = compute(df, {"kpis": spec["kpis"], "charts": spec["charts"]})
    _mark(charts)
    if not charts:
        return {"prompt": prompt, "kpis": [], "charts": [], "ai": used,
                "answer": "I couldn't match that to your columns. Try naming a column, for example: show Shortage Qty by Supplier as a pie chart."}
    return {"prompt": prompt, "kpis": kpis, "charts": charts, "answer": _answer(charts), "ai": used}


# ---------------- Favorites (saved chart recipes, reused on any new file) ----------------
import os, re as _re, uuid

FAV_PATH = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "LocalAIDash", "favorites.json")


def _norm(v):
    return _re.sub(r"[^a-z0-9]", "", str(v).lower())


def fav_list():
    try:
        with open(FAV_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _fav_write(items):
    os.makedirs(os.path.dirname(FAV_PATH), exist_ok=True)
    with open(FAV_PATH, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=1)


def fav_key(spec):
    f = spec.get("filter") or {}
    return json.dumps([spec.get("type"), _norm(spec.get("x")), _norm(spec.get("y")), spec.get("agg"),
                       _norm(f.get("column")), str(f.get("value", "")).lower()])


def _mark(charts):
    keys = {fav_key(i["spec"]) for i in fav_list()}
    for c in charts:
        c["fav"] = fav_key(c["spec"]) in keys


def fav_toggle(spec, title):
    items = fav_list()
    key = fav_key(spec)
    keep = [i for i in items if fav_key(i["spec"]) != key]
    on = len(keep) == len(items)
    if on:
        clean = {k: spec.get(k) for k in ("type", "x", "y", "agg", "filter")}
        keep.append({"id": uuid.uuid4().hex[:8], "title": title, "spec": clean})
    _fav_write(keep)
    return {"on": on, "count": len(keep)}


def _remap(df, spec):
    cols = {_norm(c): c for c in df.columns}
    out = dict(spec)
    for k in ("x", "y"):
        if spec.get(k):
            if _norm(spec[k]) not in cols:
                return None
            out[k] = cols[_norm(spec[k])]
    f = spec.get("filter")
    if f:
        if _norm(f["column"]) not in cols:
            return None
        out["filter"] = {"column": cols[_norm(f["column"])], "value": f["value"]}
    return out


def fav_apply(path):
    items = fav_list()
    df = get_df(path)
    prof = profile(df)
    charts, skipped = [], []
    for it in items:
        m = _remap(df, it["spec"])
        ok = _valid(df, prof, {"kpis": [], "charts": [m]})["charts"] if m else []
        got = compute(df, {"kpis": [], "charts": ok})[1] if ok else []
        if got:
            got[0]["fav"] = True
            charts.append(got[0])
        else:
            skipped.append(it["title"])
    return {"charts": charts, "skipped": skipped, "count": len(items)}
