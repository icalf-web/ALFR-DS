import ctypes, json, os, subprocess, sys, threading, time
import requests, webview
import engine

BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(BASE)
DATA = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "LocalAIDash")
MODELS = os.path.join(DATA, "models")
PREFS = os.path.join(DATA, "prefs.json")


class Api:
    def __init__(self):
        self._proc = None
        self._pull = {"state": "idle", "pct": 0, "msg": ""}
        self._window = None

    # ---- Ollama lifecycle (hidden background process, local only) ----
    def start_engine(self):
        if self._up():
            self._warm()
            return
        exe = next((p for p in (os.path.join(APP_DIR, "ollama", "ollama.exe"),
                                os.path.join(BASE, "ollama", "ollama.exe")) if os.path.exists(p)), "ollama")
        env = dict(os.environ, OLLAMA_MODELS=MODELS, OLLAMA_HOST="127.0.0.1:11434")
        try:
            self._proc = subprocess.Popen([exe, "serve"], env=env, stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL,
                                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError:
            self._proc = None
        for _ in range(40):
            if self._up():
                break
            time.sleep(0.5)
        self._warm()

    def _warm(self):
        """Load the model into memory in the background so the first AI prompt is fast."""
        try:
            if self._up() and self._has_model():
                requests.post(f"{engine.OLLAMA}/api/generate",
                              json={"model": engine.MODEL, "keep_alive": "30m"}, timeout=180)
        except Exception:
            pass

    def _up(self):
        try:
            return requests.get(engine.OLLAMA, timeout=1).ok
        except Exception:
            return False

    def _has_model(self):
        try:
            tags = requests.get(f"{engine.OLLAMA}/api/tags", timeout=3).json()["models"]
            return any(m["name"].startswith(engine.MODEL) for m in tags)
        except Exception:
            return False

    def status(self):
        up = self._up()
        return {"engine": up, "model": up and self._has_model(), "pull": self._pull}

    def setup_model(self):
        if self._pull["state"] == "running":
            return
        def run():
            self._pull = {"state": "running", "pct": 0, "msg": "Starting"}
            try:
                with requests.post(f"{engine.OLLAMA}/api/pull", json={"model": engine.MODEL, "stream": True},
                                   stream=True, timeout=30) as r:
                    for line in r.iter_lines():
                        if not line:
                            continue
                        d = json.loads(line)
                        pct = int(100 * d.get("completed", 0) / d["total"]) if d.get("total") else self._pull["pct"]
                        self._pull = {"state": "running", "pct": pct, "msg": d.get("status", "")}
                self._pull = {"state": "done", "pct": 100, "msg": "Ready"}
            except Exception as e:
                self._pull = {"state": "error", "pct": 0, "msg": str(e)}
        threading.Thread(target=run, daemon=True).start()

    # ---- Dashboard ----
    def pick_file(self):
        r = self._window.create_file_dialog(
            webview.OPEN_DIALOG, file_types=("Spreadsheets (*.xlsx;*.xls;*.csv)",))
        return r[0] if r else None

    def ask(self, path, prompt):
        try:
            return {"ok": True, "data": engine.ask(path, prompt, ai_ready=self._up() and self._has_model())}
        except Exception as e:
            return {"ok": False, "error": f"Could not answer: {e}"}

    def _load_prefs(self):
        try:
            with open(PREFS, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def _save_prefs(self, d):
        try:
            os.makedirs(DATA, exist_ok=True)
            with open(PREFS, "w", encoding="utf-8") as f:
                json.dump(d, f, indent=1)
        except Exception:
            pass

    def get_prefs(self):
        d = self._load_prefs()
        return {"layout": d.get("layout", "grid"), "collapsed": bool(d.get("collapsed", False))}

    def set_pref(self, key, value):
        if key in ("layout", "collapsed"):
            d = self._load_prefs()
            d[key] = value
            self._save_prefs(d)
        return True

    def set_title(self, path, title):
        d = self._load_prefs()
        t = d.setdefault("titles", {})
        title = (title or "").strip()[:120]
        if title:
            t[path] = title
        else:
            t.pop(path, None)
        self._save_prefs(d)
        return True

    def load_file(self, path):
        try:
            d = engine.info(path)
            d["file"] = os.path.basename(path)
            d["title"] = self._load_prefs().get("titles", {}).get(path, "")
            return {"ok": True, "data": d}
        except Exception as e:
            return {"ok": False, "error": f"Could not read this file: {e}"}

    def preview(self, path):
        try:
            return {"ok": True, "data": engine.preview(path)}
        except Exception as e:
            return {"ok": False, "error": f"Could not show the table: {e}"}

    def fav_toggle(self, spec, title):
        return engine.fav_toggle(spec, title)

    def fav_count(self):
        return len(engine.fav_list())

    def fav_apply(self, path):
        try:
            return engine.fav_apply(path)
        except Exception as e:
            return {"charts": [], "skipped": [], "count": 0, "error": str(e)}

    def build(self, path):
        try:
            out = engine.build(path, ai_ready=self._up() and self._has_model())
            out["file"] = os.path.basename(path)
            return {"ok": True, "data": out}
        except Exception as e:
            return {"ok": False, "error": f"Could not read this file: {e}"}

    def stop(self):
        if self._proc:
            self._proc.terminate()


def set_window_icon():
    """Put the eye logo on the app window and taskbar button (Windows only). Retries for ~20 s."""
    if sys.platform != "win32":
        return
    try:
        from ctypes import wintypes
        u = ctypes.windll.user32
        u.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        u.LoadImageW.restype = wintypes.HANDLE
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.SendMessageW.restype = ctypes.c_ssize_t
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        ico = os.path.join(BASE, "icon.ico")
        big = u.LoadImageW(None, ico, 1, 48, 48, 0x10)
        small = u.LoadImageW(None, ico, 1, 16, 16, 0x10)
        if not big or not small:
            raise RuntimeError("could not load " + ico)

        def mine():
            found = []

            def cb(h, _):
                pid = wintypes.DWORD()
                u.GetWindowThreadProcessId(h, ctypes.byref(pid))
                if pid.value == os.getpid() and u.IsWindowVisible(h):
                    buf = ctypes.create_unicode_buffer(256)
                    u.GetWindowTextW(h, buf, 256)
                    if "Local AI Dashboard" in buf.value:
                        found.append(h)
                return True
            u.EnumWindows(proc(cb), 0)
            return found

        for _ in range(40):
            for h in mine():
                u.SendMessageW(h, 0x80, 0, small)
                u.SendMessageW(h, 0x80, 1, big)
            time.sleep(0.5)
    except Exception as e:
        try:
            os.makedirs(DATA, exist_ok=True)
            open(os.path.join(DATA, "icon.log"), "w").write(repr(e))
        except Exception:
            pass


def main():
    if sys.platform == "win32":
        try:  # own taskbar identity so Windows doesn't group us under Python
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("LocalAIDashboard.App")
        except Exception:
            pass
    api = Api()
    threading.Thread(target=api.start_engine, daemon=True).start()
    api._window = webview.create_window("Local AI Dashboard", os.path.join(BASE, "ui", "index.html"),
                                       js_api=api, width=1280, height=820, min_size=(900, 620),
                                       background_color="#FFFFFF")
    webview.start(set_window_icon)
    api.stop()


if __name__ == "__main__":
    main()
