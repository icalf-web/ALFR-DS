@echo off
setlocal EnableExtensions
title Uninstall Local AI Dashboard
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "DATA=%LocalAppData%\LocalAIDash"
set "ISAPP=0"
if exist "%ROOT%\app\main.py" if exist "%ROOT%\Setup.bat" set "ISAPP=1"
set "PYFLAG=0"
if exist "%DATA%\python_installed.flag" set "PYFLAG=1"

echo ============================================================
echo   Uninstall Local AI Dashboard
echo ============================================================
echo This removes everything the app installed:
echo   - the AI model, your favorites, titles and settings
echo       %DATA%
echo   - the AI engine, Python libraries and build files
echo   - the Desktop shortcut
if "%ISAPP%"=="1" echo   - this whole program folder: %ROOT%
if "%PYFLAG%"=="1" echo   - Python 3.11, which this app installed
echo.
echo Your own Excel files are NOT touched.
echo.
choice /c YN /n /m "Press Y to uninstall everything, or N to cancel: "
if errorlevel 2 goto cancel

echo.
echo [1/5] Stopping the app...
set "KILL1=%DATA%"
if "%ISAPP%"=="1" set "KILL1=%ROOT%"
powershell -NoProfile -Command "Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -and ($_.Path.StartsWith('%KILL1%\',[StringComparison]::OrdinalIgnoreCase) -or $_.Path.StartsWith('%DATA%\',[StringComparison]::OrdinalIgnoreCase)) } | Stop-Process -Force -ErrorAction SilentlyContinue"
timeout /t 2 /nobreak >nul

echo [2/5] Removing the AI model, favorites and settings...
if exist "%DATA%" rmdir /s /q "%DATA%"

echo [3/5] Removing the Desktop shortcut...
powershell -NoProfile -Command "Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Local AI Dashboard.lnk') -Force -ErrorAction SilentlyContinue"

echo [4/5] Python...
if "%PYFLAG%"=="1" goto removepy
choice /c YN /n /t 15 /d N /m "Also remove Python 3.11? Choose N if you use Python for anything else [y/N]: "
if errorlevel 2 goto skippy
:removepy
winget uninstall -e --id Python.Python.3.11 --silent
goto afterpy
:skippy
echo Python left in place.
:afterpy

echo [5/5] Removing program files...
if "%ISAPP%"=="1" goto delfolder
echo This copy of Uninstall.bat is not inside the program folder, so the folder was not deleted.
echo Delete the LocalAIDash folder yourself to finish.
goto finish
:delfolder
cd /d "%TEMP%"
start "" powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep 8; Remove-Item -LiteralPath '%ROOT%' -Recurse -Force -ErrorAction SilentlyContinue"

:finish
echo.
echo Done. Local AI Dashboard has been removed. This window will close shortly.
timeout /t 5 >nul
exit /b 0

:cancel
echo Cancelled. Nothing was removed.
timeout /t 3 >nul
exit /b 0
